<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Kelly</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <?php echo $__env->make('libraries.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
</head>

<body>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('components.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->

  <!--Content-->
  <?php echo $__env->yieldContent('content'); ?>
  <!--End Content-->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('libraries.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH G:\Laravel\Portfolio\resources\views/layouts/app.blade.php ENDPATH**/ ?>